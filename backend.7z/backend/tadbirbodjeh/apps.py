from django.apps import AppConfig


class TadbirbodjehConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "tadbirbodjeh"

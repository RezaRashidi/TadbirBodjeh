"use client";

import Register from "@/app/components/Register";

export default function Home() {
    return (
        <main>
            <Register/>
        </main>
    );
}
import Login from "@/app/components/Login";

export default function Home() {
  return (
      <main className="flex min-h-screen flex-col items-center justify-between p-24">


          <main>
              <Login/>
          </main>

      </main>
  );
}
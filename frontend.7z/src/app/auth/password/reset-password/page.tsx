"use client";

import ResetPassword from "@/app/components/ResetPassword";

export default function Home() {
    return (
        <main>
            <ResetPassword/>
        </main>
    );
}
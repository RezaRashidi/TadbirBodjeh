"use client";

import ResetPasswordConfirmation from "@/app/components/ResetPasswordConfirmation";

export default function Home() {
    return (
        <main>
            <ResetPasswordConfirmation/>
        </main>
    );
}